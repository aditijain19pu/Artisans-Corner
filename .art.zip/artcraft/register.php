<?php
  $name= $_POST["name"];
  $email= $_POST["email"];
  $contact= $_POST["contact"];
  $age= $_POST["age"];
  $username= $_POST["username"];
  $password= $_POST["password"];

  //database connection
?>
